from django.contrib import admin
from apply.models import Application
# Register your models here.
admin.site.register(Application)